import asyncio
import re
import json
import os
import httpx
import signal
from datetime import datetime
from telegram.ext import CommandHandler
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, CopyTextButton
from telegram.ext import ApplicationBuilder

# ============================================================
# KONFIGURASI
# ============================================================
BOT_TOKEN = "9019042029:AAHwJWNrPVypnw744RdBjAx8rdkHt8H1Gs0"
SETTINGS_FILE = "bot_settings.json"
ADMIN_IDS = [7853394864]
CH_INFO = "https://t.me/xbddiscusion"
NUMBER_BOT = "https://t.me/filenumberxbd"

# FIX: Hapus 'app.' dari URL sesuai dokumentasi
API_URL = "https://thirdwave.im/api/v1/traffic"
API_KEY = "tw_wpQGFuR5vnTL7NiUrUswTKSdTocfBnozR8871JrBeiU"
POLL_INTERVAL = 10  # Seconds between API checks

# Emoji ikon pada tombol di bawah pesan SMS (isi dengan custom emoji ID).
# Cara dapat ID: kirim custom emoji ke bot (chat pribadi, admin), bot akan membalas ID-nya.
BTN_EMOJI_OTP = "6206495649895028694"      # tombol kode OTP
BTN_EMOJI_MESSAGE = "6206112371308500200"  # tombol MESAGE (kalau OTP tidak ada)
BTN_EMOJI_NUMBER = "6291634155243444259"   # tombol NUMBER
BTN_EMOJI_INFO = "6289372614443933228"     # tombol NFO

# Pengganti titik di tengah nomor (contoh: 9647⭐4800).
# MASK_EMOJI = emoji biasa. Kalau MASK_CUSTOM_EMOJI_ID diisi, emoji itu diganti custom emoji.
MASK_EMOJI = "✨"
MASK_CUSTOM_EMOJI_ID = "6305054313135742821"
MASK_COUNT = 1  # jumlah emoji di tengah nomor

# Emoji di samping garis ┃ pada pesan SMS (kosongkan "" kalau tidak mau). Posisi: di kiri garis.
BAR_EMOJI_ID = "5386367538735104399"


# ============================================================
# ANSI COLORS
# ============================================================
C_GREEN = '\033[92m'
C_RED = '\033[91m'
C_CYAN = '\033[96m'
C_BLUE = '\033[94m'
C_YELLOW = '\033[93m'
C_RESET = '\033[0m'

# ============================================================
# DATABASE (JSON-based)
# ============================================================
class Database:
    BASE_DIR = "database"

    @classmethod
    def init_db(cls):
        os.makedirs(cls.BASE_DIR, exist_ok=True)
        default_files = {
            "groups.json": {"groups": []},
            "sms_history.json": [],
            "bot_messages.json": []
        }
        for file, content in default_files.items():
            path = os.path.join(cls.BASE_DIR, file)
            if not os.path.exists(path):
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(content, f, indent=4, ensure_ascii=False)

    @classmethod
    def load_groups(cls):
        path = os.path.join(cls.BASE_DIR, "groups.json")
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data.get("groups", [])
            except:
                pass
        return []

    @classmethod
    def save_groups(cls, groups):
        path = os.path.join(cls.BASE_DIR, "groups.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"groups": groups}, f, indent=4, ensure_ascii=False)

    @classmethod
    def add_group(cls, group_id):
        gid_str = str(group_id).strip()
        if gid_str.startswith("100") and len(gid_str) >= 13:
            gid_str = "-" + gid_str
            
        if not re.match(r'^-?\d+$', gid_str):
            return False
            
        groups = cls.load_groups()
        if gid_str not in groups:
            groups.append(gid_str)
            cls.save_groups(groups)
            return True
        return False

    @classmethod
    def load_countries(cls):
        path = os.path.join(cls.BASE_DIR, "country.json")
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except:
                pass
        return {}

    @classmethod
    def check_sms_history(cls, phone, datetime_str):
        path = os.path.join(cls.BASE_DIR, "sms_history.json")
        history = []
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    history = json.load(f)
            except:
                pass
        sms_id = f"{phone}_{datetime_str}"
        if sms_id in history:
            return True
        history.append(sms_id)
        if len(history) > 1000:
            history = history[-1000:]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=4, ensure_ascii=False)
        return False

    @classmethod
    def add_bot_message(cls, group_id, message_id):
        path = os.path.join(cls.BASE_DIR, "bot_messages.json")
        data = []
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except:
                pass
        data.append({
            "group_id": group_id,
            "message_id": message_id,
            "timestamp": datetime.now().isoformat()
        })
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    @classmethod
    def get_old_bot_messages(cls, older_than_minutes):
        path = os.path.join(cls.BASE_DIR, "bot_messages.json")
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            return []
        now = datetime.now()
        old = []
        for msg in data:
            try:
                ts = datetime.fromisoformat(msg["timestamp"])
                if (now - ts).total_seconds() > older_than_minutes * 60:
                    old.append(msg)
            except:
                pass
        return old

    @classmethod
    def remove_bot_message(cls, group_id, message_id):
        path = os.path.join(cls.BASE_DIR, "bot_messages.json")
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            return
        new_data = [m for m in data if not (m["group_id"] == group_id and m["message_id"] == message_id)]
        if len(new_data) != len(data):
            with open(path, "w", encoding="utf-8") as f:
                json.dump(new_data, f, indent=4, ensure_ascii=False)


# ============================================================
# COUNTRY INFO (dari country.json)
# ============================================================
COUNTRY_CODES = Database.load_countries()

# Daftar negara lengkap (kode telepon -> negara). Dipakai hanya untuk kode yang
# belum ada di country.json, jadi data country.json (termasuk custom_emoji_id) tetap diutamakan.
# Isi "custom_emoji_id" di sini kalau mau bendera custom emoji untuk negara tertentu.
EXTRA_COUNTRIES = {
    "1": {"name": "United States", "flag": "🇺🇸", "shortName": "US", "custom_emoji_id": "", "code": "1"},
    "7": {"name": "Russia", "flag": "🇷🇺", "shortName": "RU", "custom_emoji_id": "", "code": "7"},
    "20": {"name": "Egypt", "flag": "🇪🇬", "shortName": "EG", "custom_emoji_id": "", "code": "20"},
    "27": {"name": "South Africa", "flag": "🇿🇦", "shortName": "ZA", "custom_emoji_id": "", "code": "27"},
    "30": {"name": "Greece", "flag": "🇬🇷", "shortName": "GR", "custom_emoji_id": "", "code": "30"},
    "31": {"name": "Netherlands", "flag": "🇳🇱", "shortName": "NL", "custom_emoji_id": "", "code": "31"},
    "32": {"name": "Belgium", "flag": "🇧🇪", "shortName": "BE", "custom_emoji_id": "", "code": "32"},
    "33": {"name": "France", "flag": "🇫🇷", "shortName": "FR", "custom_emoji_id": "", "code": "33"},
    "34": {"name": "Spain", "flag": "🇪🇸", "shortName": "ES", "custom_emoji_id": "", "code": "34"},
    "36": {"name": "Hungary", "flag": "🇭🇺", "shortName": "HU", "custom_emoji_id": "", "code": "36"},
    "39": {"name": "Italy", "flag": "🇮🇹", "shortName": "IT", "custom_emoji_id": "", "code": "39"},
    "40": {"name": "Romania", "flag": "🇷🇴", "shortName": "RO", "custom_emoji_id": "", "code": "40"},
    "41": {"name": "Switzerland", "flag": "🇨🇭", "shortName": "CH", "custom_emoji_id": "", "code": "41"},
    "43": {"name": "Austria", "flag": "🇦🇹", "shortName": "AT", "custom_emoji_id": "", "code": "43"},
    "44": {"name": "United Kingdom", "flag": "🇬🇧", "shortName": "GB", "custom_emoji_id": "", "code": "44"},
    "45": {"name": "Denmark", "flag": "🇩🇰", "shortName": "DK", "custom_emoji_id": "", "code": "45"},
    "46": {"name": "Sweden", "flag": "🇸🇪", "shortName": "SE", "custom_emoji_id": "", "code": "46"},
    "47": {"name": "Norway", "flag": "🇳🇴", "shortName": "NO", "custom_emoji_id": "", "code": "47"},
    "48": {"name": "Poland", "flag": "🇵🇱", "shortName": "PL", "custom_emoji_id": "", "code": "48"},
    "49": {"name": "Germany", "flag": "🇩🇪", "shortName": "DE", "custom_emoji_id": "", "code": "49"},
    "51": {"name": "Peru", "flag": "🇵🇪", "shortName": "PE", "custom_emoji_id": "", "code": "51"},
    "52": {"name": "Mexico", "flag": "🇲🇽", "shortName": "MX", "custom_emoji_id": "", "code": "52"},
    "53": {"name": "Cuba", "flag": "🇨🇺", "shortName": "CU", "custom_emoji_id": "", "code": "53"},
    "54": {"name": "Argentina", "flag": "🇦🇷", "shortName": "AR", "custom_emoji_id": "", "code": "54"},
    "55": {"name": "Brazil", "flag": "🇧🇷", "shortName": "BR", "custom_emoji_id": "", "code": "55"},
    "56": {"name": "Chile", "flag": "🇨🇱", "shortName": "CL", "custom_emoji_id": "", "code": "56"},
    "57": {"name": "Colombia", "flag": "🇨🇴", "shortName": "CO", "custom_emoji_id": "", "code": "57"},
    "58": {"name": "Venezuela", "flag": "🇻🇪", "shortName": "VE", "custom_emoji_id": "", "code": "58"},
    "60": {"name": "Malaysia", "flag": "🇲🇾", "shortName": "MY", "custom_emoji_id": "", "code": "60"},
    "61": {"name": "Australia", "flag": "🇦🇺", "shortName": "AU", "custom_emoji_id": "", "code": "61"},
    "62": {"name": "Indonesia", "flag": "🇮🇩", "shortName": "ID", "custom_emoji_id": "", "code": "62"},
    "63": {"name": "Philippines", "flag": "🇵🇭", "shortName": "PH", "custom_emoji_id": "", "code": "63"},
    "64": {"name": "New Zealand", "flag": "🇳🇿", "shortName": "NZ", "custom_emoji_id": "", "code": "64"},
    "65": {"name": "Singapore", "flag": "🇸🇬", "shortName": "SG", "custom_emoji_id": "", "code": "65"},
    "66": {"name": "Thailand", "flag": "🇹🇭", "shortName": "TH", "custom_emoji_id": "", "code": "66"},
    "76": {"name": "Kazakhstan", "flag": "🇰🇿", "shortName": "KZ", "custom_emoji_id": "", "code": "76"},
    "77": {"name": "Kazakhstan", "flag": "🇰🇿", "shortName": "KZ", "custom_emoji_id": "", "code": "77"},
    "81": {"name": "Japan", "flag": "🇯🇵", "shortName": "JP", "custom_emoji_id": "", "code": "81"},
    "82": {"name": "South Korea", "flag": "🇰🇷", "shortName": "KR", "custom_emoji_id": "", "code": "82"},
    "84": {"name": "Vietnam", "flag": "🇻🇳", "shortName": "VN", "custom_emoji_id": "", "code": "84"},
    "86": {"name": "China", "flag": "🇨🇳", "shortName": "CN", "custom_emoji_id": "", "code": "86"},
    "90": {"name": "Turkey", "flag": "🇹🇷", "shortName": "TR", "custom_emoji_id": "", "code": "90"},
    "91": {"name": "India", "flag": "🇮🇳", "shortName": "IN", "custom_emoji_id": "", "code": "91"},
    "92": {"name": "Pakistan", "flag": "🇵🇰", "shortName": "PK", "custom_emoji_id": "", "code": "92"},
    "93": {"name": "Afghanistan", "flag": "🇦🇫", "shortName": "AF", "custom_emoji_id": "", "code": "93"},
    "94": {"name": "Sri Lanka", "flag": "🇱🇰", "shortName": "LK", "custom_emoji_id": "", "code": "94"},
    "95": {"name": "Myanmar", "flag": "🇲🇲", "shortName": "MM", "custom_emoji_id": "", "code": "95"},
    "98": {"name": "Iran", "flag": "🇮🇷", "shortName": "IR", "custom_emoji_id": "", "code": "98"},
    "211": {"name": "South Sudan", "flag": "🇸🇸", "shortName": "SS", "custom_emoji_id": "", "code": "211"},
    "212": {"name": "Morocco", "flag": "🇲🇦", "shortName": "MA", "custom_emoji_id": "", "code": "212"},
    "213": {"name": "Algeria", "flag": "🇩🇿", "shortName": "DZ", "custom_emoji_id": "", "code": "213"},
    "216": {"name": "Tunisia", "flag": "🇹🇳", "shortName": "TN", "custom_emoji_id": "", "code": "216"},
    "218": {"name": "Libya", "flag": "🇱🇾", "shortName": "LY", "custom_emoji_id": "", "code": "218"},
    "220": {"name": "Gambia", "flag": "🇬🇲", "shortName": "GM", "custom_emoji_id": "", "code": "220"},
    "221": {"name": "Senegal", "flag": "🇸🇳", "shortName": "SN", "custom_emoji_id": "", "code": "221"},
    "222": {"name": "Mauritania", "flag": "🇲🇷", "shortName": "MR", "custom_emoji_id": "", "code": "222"},
    "223": {"name": "Mali", "flag": "🇲🇱", "shortName": "ML", "custom_emoji_id": "", "code": "223"},
    "224": {"name": "Guinea", "flag": "🇬🇳", "shortName": "GN", "custom_emoji_id": "", "code": "224"},
    "225": {"name": "Ivory Coast", "flag": "🇨🇮", "shortName": "CI", "custom_emoji_id": "", "code": "225"},
    "226": {"name": "Burkina Faso", "flag": "🇧🇫", "shortName": "BF", "custom_emoji_id": "", "code": "226"},
    "227": {"name": "Niger", "flag": "🇳🇪", "shortName": "NE", "custom_emoji_id": "", "code": "227"},
    "228": {"name": "Togo", "flag": "🇹🇬", "shortName": "TG", "custom_emoji_id": "", "code": "228"},
    "229": {"name": "Benin", "flag": "🇧🇯", "shortName": "BJ", "custom_emoji_id": "", "code": "229"},
    "230": {"name": "Mauritius", "flag": "🇲🇺", "shortName": "MU", "custom_emoji_id": "", "code": "230"},
    "231": {"name": "Liberia", "flag": "🇱🇷", "shortName": "LR", "custom_emoji_id": "", "code": "231"},
    "232": {"name": "Sierra Leone", "flag": "🇸🇱", "shortName": "SL", "custom_emoji_id": "", "code": "232"},
    "233": {"name": "Ghana", "flag": "🇬🇭", "shortName": "GH", "custom_emoji_id": "", "code": "233"},
    "234": {"name": "Nigeria", "flag": "🇳🇬", "shortName": "NG", "custom_emoji_id": "", "code": "234"},
    "235": {"name": "Chad", "flag": "🇹🇩", "shortName": "TD", "custom_emoji_id": "", "code": "235"},
    "236": {"name": "Central African Republic", "flag": "🇨🇫", "shortName": "CF", "custom_emoji_id": "", "code": "236"},
    "237": {"name": "Cameroon", "flag": "🇨🇲", "shortName": "CM", "custom_emoji_id": "", "code": "237"},
    "238": {"name": "Cape Verde", "flag": "🇨🇻", "shortName": "CV", "custom_emoji_id": "", "code": "238"},
    "239": {"name": "Sao Tome & Principe", "flag": "🇸🇹", "shortName": "ST", "custom_emoji_id": "", "code": "239"},
    "240": {"name": "Equatorial Guinea", "flag": "🇬🇶", "shortName": "GQ", "custom_emoji_id": "", "code": "240"},
    "241": {"name": "Gabon", "flag": "🇬🇦", "shortName": "GA", "custom_emoji_id": "", "code": "241"},
    "242": {"name": "Congo", "flag": "🇨🇬", "shortName": "CG", "custom_emoji_id": "", "code": "242"},
    "243": {"name": "DR Congo", "flag": "🇨🇩", "shortName": "CD", "custom_emoji_id": "", "code": "243"},
    "244": {"name": "Angola", "flag": "🇦🇴", "shortName": "AO", "custom_emoji_id": "", "code": "244"},
    "245": {"name": "Guinea-Bissau", "flag": "🇬🇼", "shortName": "GW", "custom_emoji_id": "", "code": "245"},
    "246": {"name": "British Indian Ocean Territory", "flag": "🇮🇴", "shortName": "IO", "custom_emoji_id": "", "code": "246"},
    "248": {"name": "Seychelles", "flag": "🇸🇨", "shortName": "SC", "custom_emoji_id": "", "code": "248"},
    "249": {"name": "Sudan", "flag": "🇸🇩", "shortName": "SD", "custom_emoji_id": "", "code": "249"},
    "250": {"name": "Rwanda", "flag": "🇷🇼", "shortName": "RW", "custom_emoji_id": "", "code": "250"},
    "251": {"name": "Ethiopia", "flag": "🇪🇹", "shortName": "ET", "custom_emoji_id": "", "code": "251"},
    "252": {"name": "Somalia", "flag": "🇸🇴", "shortName": "SO", "custom_emoji_id": "", "code": "252"},
    "253": {"name": "Djibouti", "flag": "🇩🇯", "shortName": "DJ", "custom_emoji_id": "", "code": "253"},
    "254": {"name": "Kenya", "flag": "🇰🇪", "shortName": "KE", "custom_emoji_id": "", "code": "254"},
    "255": {"name": "Tanzania", "flag": "🇹🇿", "shortName": "TZ", "custom_emoji_id": "", "code": "255"},
    "256": {"name": "Uganda", "flag": "🇺🇬", "shortName": "UG", "custom_emoji_id": "", "code": "256"},
    "257": {"name": "Burundi", "flag": "🇧🇮", "shortName": "BI", "custom_emoji_id": "", "code": "257"},
    "258": {"name": "Mozambique", "flag": "🇲🇿", "shortName": "MZ", "custom_emoji_id": "", "code": "258"},
    "260": {"name": "Zambia", "flag": "🇿🇲", "shortName": "ZM", "custom_emoji_id": "", "code": "260"},
    "261": {"name": "Madagascar", "flag": "🇲🇬", "shortName": "MG", "custom_emoji_id": "", "code": "261"},
    "262": {"name": "Reunion", "flag": "🇷🇪", "shortName": "RE", "custom_emoji_id": "", "code": "262"},
    "263": {"name": "Zimbabwe", "flag": "🇿🇼", "shortName": "ZW", "custom_emoji_id": "", "code": "263"},
    "264": {"name": "Namibia", "flag": "🇳🇦", "shortName": "NA", "custom_emoji_id": "", "code": "264"},
    "265": {"name": "Malawi", "flag": "🇲🇼", "shortName": "MW", "custom_emoji_id": "", "code": "265"},
    "266": {"name": "Lesotho", "flag": "🇱🇸", "shortName": "LS", "custom_emoji_id": "", "code": "266"},
    "267": {"name": "Botswana", "flag": "🇧🇼", "shortName": "BW", "custom_emoji_id": "", "code": "267"},
    "268": {"name": "Eswatini", "flag": "🇸🇿", "shortName": "SZ", "custom_emoji_id": "", "code": "268"},
    "269": {"name": "Comoros", "flag": "🇰🇲", "shortName": "KM", "custom_emoji_id": "", "code": "269"},
    "290": {"name": "Saint Helena", "flag": "🇸🇭", "shortName": "SH", "custom_emoji_id": "", "code": "290"},
    "291": {"name": "Eritrea", "flag": "🇪🇷", "shortName": "ER", "custom_emoji_id": "", "code": "291"},
    "297": {"name": "Aruba", "flag": "🇦🇼", "shortName": "AW", "custom_emoji_id": "", "code": "297"},
    "298": {"name": "Faroe Islands", "flag": "🇫🇴", "shortName": "FO", "custom_emoji_id": "", "code": "298"},
    "299": {"name": "Greenland", "flag": "🇬🇱", "shortName": "GL", "custom_emoji_id": "", "code": "299"},
    "350": {"name": "Gibraltar", "flag": "🇬🇮", "shortName": "GI", "custom_emoji_id": "", "code": "350"},
    "351": {"name": "Portugal", "flag": "🇵🇹", "shortName": "PT", "custom_emoji_id": "", "code": "351"},
    "352": {"name": "Luxembourg", "flag": "🇱🇺", "shortName": "LU", "custom_emoji_id": "", "code": "352"},
    "353": {"name": "Ireland", "flag": "🇮🇪", "shortName": "IE", "custom_emoji_id": "", "code": "353"},
    "354": {"name": "Iceland", "flag": "🇮🇸", "shortName": "IS", "custom_emoji_id": "", "code": "354"},
    "355": {"name": "Albania", "flag": "🇦🇱", "shortName": "AL", "custom_emoji_id": "", "code": "355"},
    "356": {"name": "Malta", "flag": "🇲🇹", "shortName": "MT", "custom_emoji_id": "", "code": "356"},
    "357": {"name": "Cyprus", "flag": "🇨🇾", "shortName": "CY", "custom_emoji_id": "", "code": "357"},
    "358": {"name": "Finland", "flag": "🇫🇮", "shortName": "FI", "custom_emoji_id": "", "code": "358"},
    "359": {"name": "Bulgaria", "flag": "🇧🇬", "shortName": "BG", "custom_emoji_id": "", "code": "359"},
    "370": {"name": "Lithuania", "flag": "🇱🇹", "shortName": "LT", "custom_emoji_id": "", "code": "370"},
    "371": {"name": "Latvia", "flag": "🇱🇻", "shortName": "LV", "custom_emoji_id": "", "code": "371"},
    "372": {"name": "Estonia", "flag": "🇪🇪", "shortName": "EE", "custom_emoji_id": "", "code": "372"},
    "373": {"name": "Moldova", "flag": "🇲🇩", "shortName": "MD", "custom_emoji_id": "", "code": "373"},
    "374": {"name": "Armenia", "flag": "🇦🇲", "shortName": "AM", "custom_emoji_id": "", "code": "374"},
    "375": {"name": "Belarus", "flag": "🇧🇾", "shortName": "BY", "custom_emoji_id": "", "code": "375"},
    "376": {"name": "Andorra", "flag": "🇦🇩", "shortName": "AD", "custom_emoji_id": "", "code": "376"},
    "377": {"name": "Monaco", "flag": "🇲🇨", "shortName": "MC", "custom_emoji_id": "", "code": "377"},
    "378": {"name": "San Marino", "flag": "🇸🇲", "shortName": "SM", "custom_emoji_id": "", "code": "378"},
    "380": {"name": "Ukraine", "flag": "🇺🇦", "shortName": "UA", "custom_emoji_id": "", "code": "380"},
    "381": {"name": "Serbia", "flag": "🇷🇸", "shortName": "RS", "custom_emoji_id": "", "code": "381"},
    "382": {"name": "Montenegro", "flag": "🇲🇪", "shortName": "ME", "custom_emoji_id": "", "code": "382"},
    "383": {"name": "Kosovo", "flag": "🇽🇰", "shortName": "XK", "custom_emoji_id": "", "code": "383"},
    "385": {"name": "Croatia", "flag": "🇭🇷", "shortName": "HR", "custom_emoji_id": "", "code": "385"},
    "386": {"name": "Slovenia", "flag": "🇸🇮", "shortName": "SI", "custom_emoji_id": "", "code": "386"},
    "387": {"name": "Bosnia & Herzegovina", "flag": "🇧🇦", "shortName": "BA", "custom_emoji_id": "", "code": "387"},
    "389": {"name": "North Macedonia", "flag": "🇲🇰", "shortName": "MK", "custom_emoji_id": "", "code": "389"},
    "420": {"name": "Czech Republic", "flag": "🇨🇿", "shortName": "CZ", "custom_emoji_id": "", "code": "420"},
    "421": {"name": "Slovakia", "flag": "🇸🇰", "shortName": "SK", "custom_emoji_id": "", "code": "421"},
    "423": {"name": "Liechtenstein", "flag": "🇱🇮", "shortName": "LI", "custom_emoji_id": "", "code": "423"},
    "500": {"name": "Falkland Islands", "flag": "🇫🇰", "shortName": "FK", "custom_emoji_id": "", "code": "500"},
    "501": {"name": "Belize", "flag": "🇧🇿", "shortName": "BZ", "custom_emoji_id": "", "code": "501"},
    "502": {"name": "Guatemala", "flag": "🇬🇹", "shortName": "GT", "custom_emoji_id": "", "code": "502"},
    "503": {"name": "El Salvador", "flag": "🇸🇻", "shortName": "SV", "custom_emoji_id": "", "code": "503"},
    "504": {"name": "Honduras", "flag": "🇭🇳", "shortName": "HN", "custom_emoji_id": "", "code": "504"},
    "505": {"name": "Nicaragua", "flag": "🇳🇮", "shortName": "NI", "custom_emoji_id": "", "code": "505"},
    "506": {"name": "Costa Rica", "flag": "🇨🇷", "shortName": "CR", "custom_emoji_id": "", "code": "506"},
    "507": {"name": "Panama", "flag": "🇵🇦", "shortName": "PA", "custom_emoji_id": "", "code": "507"},
    "508": {"name": "Saint Pierre & Miquelon", "flag": "🇵🇲", "shortName": "PM", "custom_emoji_id": "", "code": "508"},
    "509": {"name": "Haiti", "flag": "🇭🇹", "shortName": "HT", "custom_emoji_id": "", "code": "509"},
    "590": {"name": "Guadeloupe", "flag": "🇬🇵", "shortName": "GP", "custom_emoji_id": "", "code": "590"},
    "591": {"name": "Bolivia", "flag": "🇧🇴", "shortName": "BO", "custom_emoji_id": "", "code": "591"},
    "592": {"name": "Guyana", "flag": "🇬🇾", "shortName": "GY", "custom_emoji_id": "", "code": "592"},
    "593": {"name": "Ecuador", "flag": "🇪🇨", "shortName": "EC", "custom_emoji_id": "", "code": "593"},
    "594": {"name": "French Guiana", "flag": "🇬🇫", "shortName": "GF", "custom_emoji_id": "", "code": "594"},
    "595": {"name": "Paraguay", "flag": "🇵🇾", "shortName": "PY", "custom_emoji_id": "", "code": "595"},
    "596": {"name": "Martinique", "flag": "🇲🇶", "shortName": "MQ", "custom_emoji_id": "", "code": "596"},
    "597": {"name": "Suriname", "flag": "🇸🇷", "shortName": "SR", "custom_emoji_id": "", "code": "597"},
    "598": {"name": "Uruguay", "flag": "🇺🇾", "shortName": "UY", "custom_emoji_id": "", "code": "598"},
    "599": {"name": "Curacao", "flag": "🇨🇼", "shortName": "CW", "custom_emoji_id": "", "code": "599"},
    "670": {"name": "Timor-Leste", "flag": "🇹🇱", "shortName": "TL", "custom_emoji_id": "", "code": "670"},
    "672": {"name": "Norfolk Island", "flag": "🇳🇫", "shortName": "NF", "custom_emoji_id": "", "code": "672"},
    "673": {"name": "Brunei", "flag": "🇧🇳", "shortName": "BN", "custom_emoji_id": "", "code": "673"},
    "674": {"name": "Nauru", "flag": "🇳🇷", "shortName": "NR", "custom_emoji_id": "", "code": "674"},
    "675": {"name": "Papua New Guinea", "flag": "🇵🇬", "shortName": "PG", "custom_emoji_id": "", "code": "675"},
    "676": {"name": "Tonga", "flag": "🇹🇴", "shortName": "TO", "custom_emoji_id": "", "code": "676"},
    "677": {"name": "Solomon Islands", "flag": "🇸🇧", "shortName": "SB", "custom_emoji_id": "", "code": "677"},
    "678": {"name": "Vanuatu", "flag": "🇻🇺", "shortName": "VU", "custom_emoji_id": "", "code": "678"},
    "679": {"name": "Fiji", "flag": "🇫🇯", "shortName": "FJ", "custom_emoji_id": "", "code": "679"},
    "680": {"name": "Palau", "flag": "🇵🇼", "shortName": "PW", "custom_emoji_id": "", "code": "680"},
    "681": {"name": "Wallis & Futuna", "flag": "🇼🇫", "shortName": "WF", "custom_emoji_id": "", "code": "681"},
    "682": {"name": "Cook Islands", "flag": "🇨🇰", "shortName": "CK", "custom_emoji_id": "", "code": "682"},
    "683": {"name": "Niue", "flag": "🇳🇺", "shortName": "NU", "custom_emoji_id": "", "code": "683"},
    "685": {"name": "Samoa", "flag": "🇼🇸", "shortName": "WS", "custom_emoji_id": "", "code": "685"},
    "686": {"name": "Kiribati", "flag": "🇰🇮", "shortName": "KI", "custom_emoji_id": "", "code": "686"},
    "687": {"name": "New Caledonia", "flag": "🇳🇨", "shortName": "NC", "custom_emoji_id": "", "code": "687"},
    "688": {"name": "Tuvalu", "flag": "🇹🇻", "shortName": "TV", "custom_emoji_id": "", "code": "688"},
    "689": {"name": "French Polynesia", "flag": "🇵🇫", "shortName": "PF", "custom_emoji_id": "", "code": "689"},
    "690": {"name": "Tokelau", "flag": "🇹🇰", "shortName": "TK", "custom_emoji_id": "", "code": "690"},
    "691": {"name": "Micronesia", "flag": "🇫🇲", "shortName": "FM", "custom_emoji_id": "", "code": "691"},
    "692": {"name": "Marshall Islands", "flag": "🇲🇭", "shortName": "MH", "custom_emoji_id": "", "code": "692"},
    "850": {"name": "North Korea", "flag": "🇰🇵", "shortName": "KP", "custom_emoji_id": "", "code": "850"},
    "852": {"name": "Hong Kong", "flag": "🇭🇰", "shortName": "HK", "custom_emoji_id": "", "code": "852"},
    "853": {"name": "Macau", "flag": "🇲🇴", "shortName": "MO", "custom_emoji_id": "", "code": "853"},
    "855": {"name": "Cambodia", "flag": "🇰🇭", "shortName": "KH", "custom_emoji_id": "", "code": "855"},
    "856": {"name": "Laos", "flag": "🇱🇦", "shortName": "LA", "custom_emoji_id": "", "code": "856"},
    "880": {"name": "Bangladesh", "flag": "🇧🇩", "shortName": "BD", "custom_emoji_id": "", "code": "880"},
    "886": {"name": "Taiwan", "flag": "🇹🇼", "shortName": "TW", "custom_emoji_id": "", "code": "886"},
    "960": {"name": "Maldives", "flag": "🇲🇻", "shortName": "MV", "custom_emoji_id": "", "code": "960"},
    "961": {"name": "Lebanon", "flag": "🇱🇧", "shortName": "LB", "custom_emoji_id": "", "code": "961"},
    "962": {"name": "Jordan", "flag": "🇯🇴", "shortName": "JO", "custom_emoji_id": "", "code": "962"},
    "963": {"name": "Syria", "flag": "🇸🇾", "shortName": "SY", "custom_emoji_id": "", "code": "963"},
    "964": {"name": "Iraq", "flag": "🇮🇶", "shortName": "IQ", "custom_emoji_id": "", "code": "964"},
    "965": {"name": "Kuwait", "flag": "🇰🇼", "shortName": "KW", "custom_emoji_id": "", "code": "965"},
    "966": {"name": "Saudi Arabia", "flag": "🇸🇦", "shortName": "SA", "custom_emoji_id": "", "code": "966"},
    "967": {"name": "Yemen", "flag": "🇾🇪", "shortName": "YE", "custom_emoji_id": "", "code": "967"},
    "968": {"name": "Oman", "flag": "🇴🇲", "shortName": "OM", "custom_emoji_id": "", "code": "968"},
    "970": {"name": "Palestine", "flag": "🇵🇸", "shortName": "PS", "custom_emoji_id": "", "code": "970"},
    "971": {"name": "United Arab Emirates", "flag": "🇦🇪", "shortName": "AE", "custom_emoji_id": "", "code": "971"},
    "972": {"name": "Israel", "flag": "🇮🇱", "shortName": "IL", "custom_emoji_id": "", "code": "972"},
    "973": {"name": "Bahrain", "flag": "🇧🇭", "shortName": "BH", "custom_emoji_id": "", "code": "973"},
    "974": {"name": "Qatar", "flag": "🇶🇦", "shortName": "QA", "custom_emoji_id": "", "code": "974"},
    "975": {"name": "Bhutan", "flag": "🇧🇹", "shortName": "BT", "custom_emoji_id": "", "code": "975"},
    "976": {"name": "Mongolia", "flag": "🇲🇳", "shortName": "MN", "custom_emoji_id": "", "code": "976"},
    "977": {"name": "Nepal", "flag": "🇳🇵", "shortName": "NP", "custom_emoji_id": "", "code": "977"},
    "992": {"name": "Tajikistan", "flag": "🇹🇯", "shortName": "TJ", "custom_emoji_id": "", "code": "992"},
    "993": {"name": "Turkmenistan", "flag": "🇹🇲", "shortName": "TM", "custom_emoji_id": "", "code": "993"},
    "994": {"name": "Azerbaijan", "flag": "🇦🇿", "shortName": "AZ", "custom_emoji_id": "", "code": "994"},
    "995": {"name": "Georgia", "flag": "🇬🇪", "shortName": "GE", "custom_emoji_id": "", "code": "995"},
    "996": {"name": "Kyrgyzstan", "flag": "🇰🇬", "shortName": "KG", "custom_emoji_id": "", "code": "996"},
    "998": {"name": "Uzbekistan", "flag": "🇺🇿", "shortName": "UZ", "custom_emoji_id": "", "code": "998"},
    "1204": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1204"},
    "1226": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1226"},
    "1236": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1236"},
    "1242": {"name": "Bahamas", "flag": "🇧🇸", "shortName": "BS", "custom_emoji_id": "", "code": "1242"},
    "1246": {"name": "Barbados", "flag": "🇧🇧", "shortName": "BB", "custom_emoji_id": "", "code": "1246"},
    "1249": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1249"},
    "1250": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1250"},
    "1264": {"name": "Anguilla", "flag": "🇦🇮", "shortName": "AI", "custom_emoji_id": "", "code": "1264"},
    "1268": {"name": "Antigua & Barbuda", "flag": "🇦🇬", "shortName": "AG", "custom_emoji_id": "", "code": "1268"},
    "1284": {"name": "British Virgin Islands", "flag": "🇻🇬", "shortName": "VG", "custom_emoji_id": "", "code": "1284"},
    "1289": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1289"},
    "1306": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1306"},
    "1340": {"name": "U.S. Virgin Islands", "flag": "🇻🇮", "shortName": "VI", "custom_emoji_id": "", "code": "1340"},
    "1343": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1343"},
    "1345": {"name": "Cayman Islands", "flag": "🇰🇾", "shortName": "KY", "custom_emoji_id": "", "code": "1345"},
    "1365": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1365"},
    "1367": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1367"},
    "1368": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1368"},
    "1382": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1382"},
    "1403": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1403"},
    "1416": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1416"},
    "1418": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1418"},
    "1431": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1431"},
    "1437": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1437"},
    "1438": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1438"},
    "1441": {"name": "Bermuda", "flag": "🇧🇲", "shortName": "BM", "custom_emoji_id": "", "code": "1441"},
    "1450": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1450"},
    "1473": {"name": "Grenada", "flag": "🇬🇩", "shortName": "GD", "custom_emoji_id": "", "code": "1473"},
    "1506": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1506"},
    "1514": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1514"},
    "1519": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1519"},
    "1548": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1548"},
    "1579": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1579"},
    "1581": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1581"},
    "1587": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1587"},
    "1604": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1604"},
    "1613": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1613"},
    "1639": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1639"},
    "1647": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1647"},
    "1649": {"name": "Turks & Caicos", "flag": "🇹🇨", "shortName": "TC", "custom_emoji_id": "", "code": "1649"},
    "1664": {"name": "Montserrat", "flag": "🇲🇸", "shortName": "MS", "custom_emoji_id": "", "code": "1664"},
    "1670": {"name": "Northern Mariana Islands", "flag": "🇲🇵", "shortName": "MP", "custom_emoji_id": "", "code": "1670"},
    "1671": {"name": "Guam", "flag": "🇬🇺", "shortName": "GU", "custom_emoji_id": "", "code": "1671"},
    "1672": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1672"},
    "1684": {"name": "American Samoa", "flag": "🇦🇸", "shortName": "AS", "custom_emoji_id": "", "code": "1684"},
    "1705": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1705"},
    "1709": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1709"},
    "1721": {"name": "Sint Maarten", "flag": "🇸🇽", "shortName": "SX", "custom_emoji_id": "", "code": "1721"},
    "1742": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1742"},
    "1758": {"name": "Saint Lucia", "flag": "🇱🇨", "shortName": "LC", "custom_emoji_id": "", "code": "1758"},
    "1767": {"name": "Dominica", "flag": "🇩🇲", "shortName": "DM", "custom_emoji_id": "", "code": "1767"},
    "1778": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1778"},
    "1780": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1780"},
    "1782": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1782"},
    "1784": {"name": "Saint Vincent", "flag": "🇻🇨", "shortName": "VC", "custom_emoji_id": "", "code": "1784"},
    "1787": {"name": "Puerto Rico", "flag": "🇵🇷", "shortName": "PR", "custom_emoji_id": "", "code": "1787"},
    "1807": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1807"},
    "1809": {"name": "Dominican Republic", "flag": "🇩🇴", "shortName": "DO", "custom_emoji_id": "", "code": "1809"},
    "1819": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1819"},
    "1825": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1825"},
    "1829": {"name": "Dominican Republic", "flag": "🇩🇴", "shortName": "DO", "custom_emoji_id": "", "code": "1829"},
    "1849": {"name": "Dominican Republic", "flag": "🇩🇴", "shortName": "DO", "custom_emoji_id": "", "code": "1849"},
    "1867": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1867"},
    "1868": {"name": "Trinidad & Tobago", "flag": "🇹🇹", "shortName": "TT", "custom_emoji_id": "", "code": "1868"},
    "1869": {"name": "Saint Kitts & Nevis", "flag": "🇰🇳", "shortName": "KN", "custom_emoji_id": "", "code": "1869"},
    "1873": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1873"},
    "1876": {"name": "Jamaica", "flag": "🇯🇲", "shortName": "JM", "custom_emoji_id": "", "code": "1876"},
    "1902": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1902"},
    "1905": {"name": "Canada", "flag": "🇨🇦", "shortName": "CA", "custom_emoji_id": "", "code": "1905"},
    "1939": {"name": "Puerto Rico", "flag": "🇵🇷", "shortName": "PR", "custom_emoji_id": "", "code": "1939"},
    "4779": {"name": "Svalbard & Jan Mayen", "flag": "🇸🇯", "shortName": "SJ", "custom_emoji_id": "", "code": "4779"},
    "5993": {"name": "Caribbean Netherlands", "flag": "🇧🇶", "shortName": "BQ", "custom_emoji_id": "", "code": "5993"},
    "5994": {"name": "Caribbean Netherlands", "flag": "🇧🇶", "shortName": "BQ", "custom_emoji_id": "", "code": "5994"},
    "5997": {"name": "Caribbean Netherlands", "flag": "🇧🇶", "shortName": "BQ", "custom_emoji_id": "", "code": "5997"},
    "35818": {"name": "Aland Islands", "flag": "🇦🇽", "shortName": "AX", "custom_emoji_id": "", "code": "35818"},
    "212528": {"name": "Western Sahara", "flag": "🇪🇭", "shortName": "EH", "custom_emoji_id": "", "code": "212528"},
    "212529": {"name": "Western Sahara", "flag": "🇪🇭", "shortName": "EH", "custom_emoji_id": "", "code": "212529"},
    "262269": {"name": "Mayotte", "flag": "🇾🇹", "shortName": "YT", "custom_emoji_id": "", "code": "262269"},
    "262639": {"name": "Mayotte", "flag": "🇾🇹", "shortName": "YT", "custom_emoji_id": "", "code": "262639"},
}

for _code, _entry in EXTRA_COUNTRIES.items():
    COUNTRY_CODES.setdefault(_code, _entry)

COUNTRY_BY_SHORT = {}
for _entry in COUNTRY_CODES.values():
    COUNTRY_BY_SHORT.setdefault(_entry.get("shortName"), _entry)

SUB_CODE_MAP = {
    "1242": "BS", "1246": "BB", "1268": "AG", "1473": "GD",
    "1758": "LC", "1767": "DM", "1784": "VC",
    "1809": "DO", "1829": "DO", "1849": "DO",
    "1868": "TT", "1869": "KN", "1876": "JM",
    "76": "KZ", "77": "KZ",
}


def get_country_info(number):
    number = number.strip().replace("+", "").replace(" ", "").replace("-", "")
    for code in sorted(COUNTRY_CODES.keys(), key=lambda x: -len(x)):
        if number.startswith(code):
            result = COUNTRY_CODES[code].copy()
            if code == "1" and number[:4] in SUB_CODE_MAP:
                sub_iso = SUB_CODE_MAP[number[:4]]
                for sub_code, sub_entry in COUNTRY_CODES.items():
                    if sub_entry.get("shortName") == sub_iso:
                        return sub_entry.copy()
                result["shortName"] = sub_iso
            elif code == "7":
                if len(number) >= 2 and number[:2] in ("76", "77"):
                    for sub_code, sub_entry in COUNTRY_CODES.items():
                        if sub_entry.get("shortName") == "KZ":
                            return sub_entry.copy()
            return result
    return {
        "name": "Unknown",
        "flag": "🌐",
        "shortName": "UN",
        "custom_emoji_id": "5816769540066906278",
        "code": number[:3] if len(number) >= 3 else "000"
    }


def mask_phone(phone):
    phone = phone.replace("+", "").replace(" ", "").replace("-", "")
    if len(phone) >= 8:
        return f"{phone[:4]}{MASK_EMOJI * MASK_COUNT}{phone[-4:]}"
    return phone


def extract_otp(message):
    patterns = [
        re.compile(r'(?:kode|code|otp|pin|verification)[\s:]*([0-9]{3,8}(?:[- ][0-9]{3,8})?)', re.IGNORECASE),
        re.compile(r'(?:adalah|is|use|gunakan)[\s:]*([0-9]{3,8}(?:[- ][0-9]{3,8})?)', re.IGNORECASE),
        re.compile(r'(?::\s*|\/|\*)?([0-9]{3,8}(?:[- ][0-9]{3,8})?)(?:\.|,|$)'),
        re.compile(r'\b([0-9]{3,8}(?:[- ][0-9]{3,8})?)\b'),
        re.compile(r'#\s*([0-9]{3,8}(?:[- ][0-9]{3,8})?)')
    ]
    for pattern in patterns:
        match = pattern.search(message)
        if match and match[1]:
            return match[1].replace(' ', '-')
    all_numbers = re.findall(r'\b\d{3,8}\b', message)
    if all_numbers:
        for num in reversed(all_numbers):
            if 3 <= len(num) <= 8:
                return num
    return "N/A"


def get_service_emoji(service):
    service_lower = service.lower() if service else ""
    if "whatsapp" in service_lower:
        return "5233354831984353090"
    if "facebook" in service_lower:
        return "5323261730283863478"
    if "instagram" in service_lower:
        return "5319160079465857105"
    if "snapchat" in service_lower:
        return "5330248916224983855"
    if "telegram" in service_lower:
        return "5330237710655306682"
    if "paypal" in service_lower:
        return "5364111181415996352"
    if "tiktok" in service_lower:
        return "5327982530702359565"
    if "discord" in service_lower:
        return "5325612636467903082"
    return "5816769540066906278"


def utf16_len(text):
    return len(text.encode("utf-16-le")) // 2


# ============================================================
# AUTO DELETE WORKER
# ============================================================
async def auto_delete_worker(application):
    while True:
        try:
            old = Database.get_old_bot_messages(10)
            for msg in old:
                try:
                    await application.bot.delete_message(
                        chat_id=msg["group_id"],
                        message_id=msg["message_id"]
                    )
                    Database.remove_bot_message(msg["group_id"], msg["message_id"])
                except:
                    pass
        except:
            pass
        await asyncio.sleep(60)


# ============================================================
# TELEGRAM SEND
# ============================================================
async def send_sms_to_groups(application, phone, message, service, otp_code, short_name, custom_emoji_id, masked_phone):
    service_emoji_id = get_service_emoji(service)
    number_emoji_id = BTN_EMOJI_NUMBER
    info_emoji_id = BTN_EMOJI_INFO

    # Bendera otomatis sesuai negara nomor (dari country.json).
    # Placeholder = emoji bendera biasa; kalau ada custom_emoji_id, diganti custom emoji.
    flag_char = COUNTRY_BY_SHORT.get(short_name, {}).get("flag") or "🌐"
    flag_len = utf16_len(flag_char)

    bar_part = "▫ " if BAR_EMOJI_ID else ""
    prefix = f"{flag_char} {short_name} "
    sms_message = f"{prefix}{bar_part}┃ ▫ {masked_phone}"
    svc_pos = len(prefix + bar_part + "┃ ")

    entities = []
    if custom_emoji_id:
        entities.append({
            "type": "custom_emoji",
            "offset": 0,
            "length": flag_len,
            "custom_emoji_id": str(custom_emoji_id)
        })
    if BAR_EMOJI_ID:
        entities.append({
            "type": "custom_emoji",
            "offset": utf16_len(prefix),
            "length": 1,
            "custom_emoji_id": str(BAR_EMOJI_ID)
        })
    entities.append({
        "type": "custom_emoji",
        "offset": utf16_len(sms_message[:svc_pos]),
        "length": 1,
        "custom_emoji_id": str(service_emoji_id)
    })
    if MASK_CUSTOM_EMOJI_ID and MASK_EMOJI in masked_phone:
        mask_start = utf16_len(sms_message[:sms_message.find(masked_phone) + 4])
        mask_len = utf16_len(MASK_EMOJI)
        for i in range(masked_phone.count(MASK_EMOJI)):
            entities.append({
                "type": "custom_emoji",
                "offset": mask_start + i * mask_len,
                "length": mask_len,
                "custom_emoji_id": str(MASK_CUSTOM_EMOJI_ID)
            })
    entities.append({
        "type": "bold",
        "offset": flag_len + 1,
        "length": utf16_len(sms_message) - (flag_len + 1)
    })
    entities.sort(key=lambda e: e["offset"])

    keyboard_buttons = []
    
    copy_val = str(message).strip() if message else ""
    if not copy_val:
        copy_val = "No message content"

    if otp_code and otp_code != "N/A":
        keyboard_buttons.append(
            InlineKeyboardButton(
                text=f"{otp_code}",
                copy_text=CopyTextButton(text=copy_val),
                api_kwargs={"icon_custom_emoji_id": BTN_EMOJI_OTP, "style": "success"}
            )
        )
    else:
        keyboard_buttons.append(
            InlineKeyboardButton(
                text=" 𝙼𝙴𝚂𝙰𝙶𝙴",
                copy_text=CopyTextButton(text=copy_val),
                api_kwargs={"icon_custom_emoji_id": BTN_EMOJI_MESSAGE, "style": "success"}
            )
        )

    bottom_row = [
        InlineKeyboardButton(
            text=" 𝙽𝚄𝙼𝙱𝙴𝚁",
            url=NUMBER_BOT,
            api_kwargs={"icon_custom_emoji_id": number_emoji_id, "style": "primary"}
        ),
        InlineKeyboardButton(
            text=" 𝙽𝙵𝙾",
            url=CH_INFO,
            api_kwargs={"icon_custom_emoji_id": info_emoji_id, "style": "primary"}
        )
    ]

    reply_markup = InlineKeyboardMarkup([keyboard_buttons, bottom_row] if bottom_row else [keyboard_buttons])

    groups = Database.load_groups()
    tasks = []

    for group_id in groups:
        gid_str = str(group_id).strip()
        if not gid_str or not re.match(r'^-?\d+$', gid_str):
            continue
        tasks.append(_send_single(application, group_id, sms_message, entities, reply_markup))

    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                settings = json.load(f)
            for nama, data in settings.get("groups", {}).items():
                tid = str(data["id"])
                if tid not in [str(g) for g in groups]:
                    tasks.append(_send_single(application, tid, sms_message, entities, reply_markup))
        except:
            pass

    if tasks:
        results = await asyncio.gather(*tasks)
        return any(results)
    return False


async def _send_single(application, chat_id, text, entities, reply_markup):
    try:
        sent_msg = await application.bot.send_message(
            chat_id=chat_id,
            text=text,
            entities=entities,
            reply_markup=reply_markup,
            link_preview_options={"is_disabled": True}
        )
        return True
    except Exception as e:
        err_msg = str(e)
        if "Flood control exceeded" in err_msg or "Retry in" in err_msg:
            print(f"{C_RED}[LIMIT] Telegram sibuk di {chat_id}! Coba lagi...{C_RESET}")
            await asyncio.sleep(3)
            return await _send_single(application, chat_id, text, entities, reply_markup)
        elif "Timed out" in err_msg or "timed out" in err_msg.lower():
            print(f"{C_RED}[NETWORK] Delay di {chat_id}, kirim ulang...{C_RESET}")
            await asyncio.sleep(2)
            return await _send_single(application, chat_id, text, entities, reply_markup)
        else:
            print(f"{C_RED}[ERROR] Gagal kirim ke {chat_id}: {err_msg}{C_RESET}")
            return False


# ============================================================
# API WORKER (FIXED FOR THIRDWAVE DOCS)
# ============================================================
async def api_worker(application):
    """Fetch data langsung dari API ThirdWave menggunakan Query Parameter."""
    seen_otps = set()

    print(f"{C_YELLOW} Starting API Worker (ThirdWave Direct)...{C_RESET}")

    # FIX: Tidak perlu header Authorization, gunakan params saja
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True, verify=False) as client:
        
        # Initial fetch to prevent sending old OTPs
        try:
            resp = await client.get(API_URL, params={"api_key": API_KEY, "limit": 100})
            
            if resp.status_code == 401:
                print(f"{C_RED}❌ FATAL: API Key Invalid atau Expired! Cek dashboard ThirdWave.{C_RESET}")
                return
                
            data = resp.json()
            # FIX: Gunakan 'items' bukan 'rows'
            rows = data.get("items", []) 
            
            for item in rows:
                # FIX: Gunakan received_at + number sebagai unique ID karena tidak ada field 'id'
                uid = f"{item.get('received_at')}_{item.get('number')}"
                seen_otps.add(uid)
            print(f"{C_GREEN}📦 Initialized with {len(seen_otps)} existing OTPs.{C_RESET}")
        except Exception as e:
            print(f"{C_RED}⚠️ Initial API fetch failed: {e}{C_RESET}")

        while True:
            try:
                # FIX: Kirim api_key via params, bukan header
                resp = await client.get(API_URL, params={"api_key": API_KEY, "limit": 50})
                
                if resp.status_code == 401:
                    print(f"{C_RED}❌ API KEY INVALID! Bot berhenti cek API sementara.{C_RESET}")
                    await asyncio.sleep(300) # Tunggu 5 menit jika key invalid
                    continue
                    
                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After", 60)
                    print(f"{C_YELLOW}⏳ Rate limit hit. Tunggu {retry_after}s...{C_RESET}")
                    await asyncio.sleep(int(retry_after))
                    continue

                data = resp.json()
                # FIX: Gunakan 'items'
                rows = data.get("items", []) 
                
                for item in reversed(rows):
                    # FIX: Unique ID baru
                    uid = f"{item.get('received_at')}_{item.get('number')}"
                    
                    if uid not in seen_otps:
                        seen_otps.add(uid)

                        # FIX: Mapping field sesuai dokumentasi ThirdWave
                        service = item.get("sender_id") or "Unknown"
                        num = item.get("number") or "Unknown"
                        msg = item.get("sms") or ""

                        country_info = get_country_info(num)
                        short_name = country_info.get("shortName", "XX")
                        custom_emoji_id = country_info.get("custom_emoji_id", "")
                        masked = mask_phone(num)
                        otp_code = extract_otp(msg)
                        print(f"\n{C_GREEN}[ NEW OTP RECEIVED ]{C_RESET}")
                        print(f"{C_CYAN}╰══ {num} - {service}{C_RESET}")

                        await send_sms_to_groups(application, num, msg, service, otp_code, short_name, custom_emoji_id, masked)
                        await asyncio.sleep(0.5)
                if len(seen_otps) > 10000:
                    seen_otps = set(list(seen_otps)[-5000:])

            except Exception as e:
                print(f"{C_RED}️ Error fetching API: {e}{C_RESET}")

            await asyncio.sleep(POLL_INTERVAL)


# ============================================================
# BOT COMMANDS
# ============================================================
async def addid(update, context):
    if update.effective_user.id not in ADMIN_IDS:
        return
    if not context.args:
        await update.message.reply_text("Format: /addid <id_grup>")
        return
    new_id = context.args[0]
    if Database.add_group(new_id):
        await update.message.reply_text(f"✅ ID Grup {new_id} berhasil ditambahkan!")
    else:
        await update.message.reply_text("⚠️ Gagal menambahkan ID. Pastikan ID berupa angka valid dan belum ada di database.")


async def delid(update, context):
    if update.effective_user.id not in ADMIN_IDS:
        return
    if not context.args:
        await update.message.reply_text("Format: /delid <id_grup>")
        return
    target_id = str(context.args[0]).strip()
    if target_id.startswith("100") and len(target_id) >= 13:
        target_id = "-" + target_id
        
    groups = Database.load_groups()
    if target_id in groups:
        groups.remove(target_id)
        Database.save_groups(groups)
        await update.message.reply_text(f"🗑️ ID Grup {target_id} berhasil dihapus!")
    else:
        alt_id = target_id[1:] if target_id.startswith("-") else "-" + target_id
        if alt_id in groups:
            groups.remove(alt_id)
            Database.save_groups(groups)
            await update.message.reply_text(f"🗑️ ID Grup {alt_id} berhasil dihapus!")
        else:
            await update.message.reply_text("⚠️ ID tidak ditemukan di database.")


async def listid(update, context):
    if update.effective_user.id not in ADMIN_IDS:
        return
    groups = Database.load_groups()
    if not groups:
        await update.message.reply_text("Database grup kosong.")
        return
    msg = f"Total Grup Terdaftar: {len(groups)}\n\n"
    for g in groups:
        msg += f"📌 {g}\n"
    await update.message.reply_text(msg)

async def ping(update, context):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    username = update.effective_user.username or "No Username"
    
    response = (
        "🏓 **Pong!**\n\n"
        f"• Bot Status: Aktif\n"
        f"• Your ID: `{user_id}`\n"
        f"• Chat ID: `{chat_id}`\n"
        f"• Admin Status: {'✅ Admin' if user_id in ADMIN_IDS else '❌ Bukan Admin'}"
    )
    await update.effective_message.reply_text(response, parse_mode="Markdown")
    print(f"{C_GREEN}[PING] Diterima dari {username} ({user_id}) di chat {chat_id}{C_RESET}")


async def traffic_stats(update, context):
    user_id = update.effective_user.id
    
    if user_id not in ADMIN_IDS:
        return

    try:
        await update.effective_message.reply_text("📊 Mengambil data traffic dari ThirdWave API...")

        # FIX: Stats juga harus pakai params, bukan header
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True, verify=False) as client:
            resp = await client.get(API_URL, params={"api_key": API_KEY, "limit": 100})
            data = resp.json()
            rows = data.get("items", []) # FIX: items bukan rows

            if not rows:
                await update.effective_message.reply_text("📭 Tidak ada data traffic ditemukan di panel.")
                return

            total_otps = len(rows)
            service_counts = {}
            country_counts = {}

            for item in rows:
                # FIX: Mapping field stats
                service = item.get("sender_id") or "Unknown"
                num = item.get("number") or "Unknown"

                service_counts[service] = service_counts.get(service, 0) + 1

                country_info = get_country_info(num)
                country_name = country_info.get("name", "Unknown")
                country_counts[country_name] = country_counts.get(country_name, 0) + 1

            sorted_services = sorted(service_counts.items(), key=lambda item: item[1], reverse=True)[:5]
            service_text = "\n".join([f"• {s}: {c}" for s, c in sorted_services])

            sorted_countries = sorted(country_counts.items(), key=lambda item: item[1], reverse=True)[:5]
            country_text = "\n".join([f"• {c}: {count}" for c, count in sorted_countries])

            stats_message = (
                f" **OTP Statistics**\n\n"
                f"Total: {total_otps}\n\n"
                f"**Top Services:**\n"
                f"{service_text}\n\n"
                f"**Top Countries:**\n"
                f"{country_text}"
            )
            await update.effective_message.reply_text(stats_message, parse_mode="Markdown")

    except Exception as e:
        print(f"{C_RED}[ERROR] Stats Error: {str(e)}{C_RESET}")
        try:
            await update.effective_message.reply_text(f"❌ Error saat mengambil data traffic: {str(e)}")
        except:
            pass


async def test_otp(update, context):
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    await update.message.reply_text(" Mengecek OTP terbaru dari ThirdWave API...")
    
    try:
        # FIX: Test command juga pakai params
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True, verify=False) as client:
            resp = await client.get(API_URL, params={"api_key": API_KEY, "limit": 1})
            data = resp.json()
            rows = data.get("items", []) # FIX: items bukan rows
            
            if not rows:
                await update.message.reply_text(" Tidak ada data traffic ditemukan di panel.")
                return
            
            item = rows[0]
            
            # FIX: Mapping field test
            service = item.get("sender_id") or "Unknown"
            num = item.get("number") or "Unknown"
            msg = item.get("sms") or ""

            country_info = get_country_info(num)
            short_name = country_info.get("shortName", "XX")
            custom_emoji_id = country_info.get("custom_emoji_id", "")
            masked = mask_phone(num)
            otp_code = extract_otp(msg)

            test_msg = (
                f"✅ **Koneksi API Berhasil!**\n\n"
                f"Pesan Terbaru:\n"
                f"• Service: {service}\n"
                f"• Number: {num}\n"
                f"• Message: {msg}\n"
                f"• OTP Code: {otp_code}"
            )
            await update.message.reply_text(test_msg, parse_mode="Markdown")
            
            await update.message.reply_text("🔄 Mengirim simulasi tampilan bot ke grup...")
            await send_sms_to_groups(context.application, num, msg, service, otp_code, short_name, custom_emoji_id, masked)
            
    except Exception as e:
        await update.message.reply_text(f"❌ Error saat mengetes API: {str(e)}")


# ============================================================
# MAIN
# ============================================================
async def main():
    print(f"{C_YELLOW}🚀 Purple Bot (Direct API) Starting...{C_RESET}")

    Database.init_db()
    groups = Database.load_groups()
    fixed_groups = []
    changed = False
    for g in groups:
        g_str = str(g).strip()
        if g_str.startswith("100") and len(g_str) >= 13:
            fixed_groups.append("-" + g_str)
            changed = True
        else:
            fixed_groups.append(g_str)
    if changed:
        Database.save_groups(fixed_groups)
        print(f"{C_YELLOW}🔧 Auto-fixed group IDs in database.{C_RESET}")

    application = ApplicationBuilder().token(BOT_TOKEN).build()
    await application.initialize()

    application.add_handler(CommandHandler("addid", addid))
    application.add_handler(CommandHandler("delid", delid))
    application.add_handler(CommandHandler("listid", listid))
    application.add_handler(CommandHandler("stats", traffic_stats))
    application.add_handler(CommandHandler("test", test_otp))
    application.add_handler(CommandHandler("ping", ping))
    try:
        await application.bot.set_my_commands([
            ("stats", "Cek statistik traffic (Admin Only)"),
            ("ping", "Cek status & ID Anda"),
            ("listid", "List ID Grup (Admin Only)"),
            ("test", "Test API (Admin Only)")
        ])
        print(f"{C_GREEN}✅ Menu perintah berhasil didaftarkan ke Telegram.{C_RESET}")
    except Exception as e:
        print(f"{C_RED}️ Gagal mendaftarkan menu perintah: {e}{C_RESET}")

    await application.start()
    await application.updater.start_polling(drop_pending_updates=True)

    asyncio.create_task(api_worker(application))
    print(f"{C_GREEN}✅ Bot aktif dan berjalan...{C_RESET}")

    stop_event = asyncio.Event()
    
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass

    await stop_event.wait()
    
    print(f"{C_YELLOW}🛑 Stopping bot...{C_RESET}")
    await application.updater.stop()
    await application.stop()
    await application.shutdown()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass